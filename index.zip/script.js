let gameCounter = 0;
const XToWin = 3;
const OToWin = 6;
const XValue = 1;
const OValue = 2;

let Player1Locations = [];
let Player2Locations = [];

let Player1CurrentScore = 0;
let Player2CurrentScore = 0;

let lastPlayedLocation = '';
let winningPlayer = '';
const winningGrids = [
    ['b1', 'b2', 'b3'],
    ['b4', 'b5', 'b6'],
    ['b7', 'b8', 'b9'],
    ['b1', 'b4', 'b7'],
    ['b2', 'b5', 'b8'],
    ['b3', 'b6', 'b9'],
    ['b1', 'b5', 'b9'],
    ['b3', 'b5', 'b7']
];

let winningarray = [];


let boxes = document.getElementsByClassName('box');
for (let i = 0; i < boxes.length; i++) {
    boxes[i].addEventListener('keyup', function (e) {
        CheckGamePlay(e)
    });
}

function CheckGamePlay(e) {
    // set gameCounter 
    gameCounter++;
    let valueTyped = e.target.value;
    let boxID = e.target.attributes.id.value

    if (valueTyped === 'x') {
        Player1Locations.push(boxID)
        Player1CurrentScore++
        console.log(Player1Locations)
        console.log("player 1 current score " + Player1CurrentScore)
    } else if (valueTyped === 'o') {
        Player2Locations.push(boxID)
        Player2CurrentScore += 2
        console.log(Player2Locations)
        console.log("player 2 current scroe " + Player2CurrentScore)
    }

    console.log("Current Game Counter ", gameCounter)
    if (Player1Locations.length >= 3 || Player2Locations.length >= 3) {
        let result = checkForWinners()
        if (result) {
            console.log("game won")

        }
    }


    console.log(gameCounter)

}


function checkForWinners() {
    //check player 1 score
    let player1score = 0;
    let player2score = 0;

    for (i = 0; i < winningGrids.length; i++) {
        player1score = 0
        player2score = 0;
        let arrayCheck = winningGrids[i]
        console.log("Winning Array To Check " + arrayCheck)
        for (j = 0; j < Player1Locations.length; j++) {
            console.log(Player1Locations)
            let result = arrayCheck.includes(Player1Locations[j])
            if (result) {
                player1score++
            }
            console.log("player 1 score is " + player1score)


        }

        for (j = 0; j < Player2Locations.length; j++) {
            let result = arrayCheck.includes(Player2Locations[j])
            console.log(Player2Locations)
            if (result) {
                player2score++
            }
            console.log("player 2 score is " + player2score)



        }
        if (player2score === 3 || player1score === 3) {
            winningarray = arrayCheck;
            break;
        }

    }



    if (player1score === 3) {
        console.log("player 1 wins")
        winningPlayer = 'P1'
        UpdateUI(winningarray)
        return true
    } else if (player2score === 3) {
        console.log("player 2 wins")
        winningPlayer = 'P2'
        UpdateUI(winningarray)
        return true;
    } else {
        return false;
    }

}

function UpdateUI(divsToUpdate) {
    for (i = 0; i < divsToUpdate.length; i++) {
        let ele = document.getElementById(divsToUpdate[i])
        ele.style.backgroundColor = 'green'
    }
}